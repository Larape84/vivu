<?php
require_once('conexion.php');

header('Content-type: application/vnd.ms-excel; charset=UTF-8');
header('Content-Disposition: attachment;filename=Reporte de inscritos en el curso de '.$_GET['curso'].'.xls');
header('Pragma: no-cache');
header('Expires: 0');
$conn=new Conexion();
$link = $conn->conectarse();
$codigo_curso=$_GET['codigo'];
$query="SELECT users.nombres, users.apellidos, users.tipodocumento, users.documento, users.tipoPoblacion, users.email, users.telefono, users.fechaNacimiento, `inscritos-cursos`.`codigo_curso`, `inscritos-cursos`.fechaRegistro As fechaRegistro FROM users,`inscritos-cursos` WHERE users.documento=`inscritos-cursos`.`documento` and `inscritos-cursos`.estado='Inscrito' and `inscritos-cursos`.codigo_curso=$codigo_curso";
$result=mysqli_query($link, $query);
?>
<h4 align="center"></h4>
<table border="1">
  <tr><td colspan="9" align="center" style="font-size: 23px;"><b>Inscritos en el grupo de <?php echo $_GET['grupo']; ?> <br>
    En el curso de <?php echo $_GET['curso']; ?></b></td></tr>
    <tr >
     <th style="background-color: #3B58B8; color: white;" class="text-center">TIPO DOCUMENTO</th>
     <th style="background-color: #3B58B8; color: white;" class="text-center">DOCUMENTO</th>
     <th style="background-color: #3B58B8; color: white;" class="text-center">NOMBRES</th>
     <th style="background-color: #3B58B8; color: white;" class="text-center">APELLIDOS</th>
     <th style="background-color: #3B58B8; color: white;" class="text-center">TIPO DE POBLACIÓN</th>
     <th style="background-color: #3B58B8; color: white;" class="text-center">TELEFONO</th>
     <th style="background-color: #3B58B8; color: white;" class="text-center">FECHA DE NACIMIENTO</th>
     <th style="background-color: #3B58B8; color: white;" class="text-center">EMAIL</th>
     <th style="background-color: #3B58B8; color: white;" class="text-center">FECHA INSCRITO</th>
   </tr>
   <?php  
   while($row=mysqli_fetch_assoc($result))
   {
    ?>
    <tr style="color: #2F2E2E;">
     <td><?php echo $row['tipodocumento'];?></td>
     <td><?php echo $row['documento'];?></td>
     <td><?php $n=strtolower($row['nombres']); echo ucwords($n);?></td>
     <td><?php $a=strtolower($row['apellidos']); echo ucwords($a);?></td>
     <td><?php echo $row['tipoPoblacion'];?></td>
     <td><?php echo $row['telefono'];?></td>
     <td><?php echo $row['fechaNacimiento'];?></td>
     <td><?php echo $row['email'];?></td>
     <td><?php echo $row['fechaRegistro'];?></td>
   </tr>
   <?php 
  } //cerrar el while
  ?>
</table>