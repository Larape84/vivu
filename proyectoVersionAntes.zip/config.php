<?php
define('DB_SERVER', 'localhost');
define('DB_SERVER_USERNAME', 'u249939424_complementario');
define('DB_SERVER_PASSWORD', 'complementario.');
define('DB_DATABASE', 'u249939424_complementario');
define('NUM_ITEMS_BY_PAGE', 12);

$connexion = new mysqli(DB_SERVER, DB_SERVER_USERNAME, DB_SERVER_PASSWORD, DB_DATABASE);
?>