<?php
$cn = mysqli_connect("localhost","u249939424_complementario","complementario.","u249939424_complementario") or die("Error");